import React from "react";
import TrackDeliveryMan from "../components/TrackDelivery/TrackDeliveryMan";

const TrackDeliveryMenPage = () => {
  return (
    <section className="overflow-y-auto mx-auto max-w-8xl px-4 py-4 space-y-6">
      <TrackDeliveryMan />
    </section>
  );
};

export default TrackDeliveryMenPage;