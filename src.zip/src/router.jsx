import { createBrowserRouter } from "react-router-dom";

import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";

import NotFoundPage from "./pages/NotFoundPage";
import DashboardPage from "./pages/DashboardPage";
import ShopPage from "./pages/ShopPage";
import MenuPage from "./pages/MenuPage";
import DeliveryPage from "./pages/DeliveryPage";
import SaleHistoryPage from "./pages/SaleHistoryPage";
import ReportPage from "./pages/ReportPage";
import ManagementPage from "./pages/ManagementPage";
import AddDeliveryMen from "./pages/AddDeliveryMenPage";
import TrackDeliveryMen from "./pages/TrackDeliveryMenPage";
import OrderReceivePage from "./pages/OrderReceivePage";
import AssignDeliveryMan from "./pages/AssignDeliveryManPage";
import MenuListPage from "./pages/MenuListPage";
import MenuDetail from "./components/Shop/MenuDetail";
import LoginPage from "./pages/LoginPage";
import ShopDetailsModal from "./components/Management/ShopDetailsModal";
import ReportTable from "./components/Report/ReportTable";
import SettingPage from "./pages/SettingPage";

const router = createBrowserRouter([
  {
    path: "/login",
    element: <LoginPage />,
  },

  {
    path: "/",
    element: (
      <ProtectedRoute>
        <Layout />
      </ProtectedRoute>
    ),
    errorElement: <NotFoundPage />,

    children: [
      {
        index: true,
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
              "admin",
            ]}
          >
            <DashboardPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/shop",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <ShopPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/shop/details/:id",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <ShopDetailsModal />
          </ProtectedRoute>
        ),
      },

      {
        path: "/menu",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <MenuPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/shop/menu-list/:shopId",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <MenuListPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/orders/received",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <OrderReceivePage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/delivery",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <DeliveryPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/orders/assignment",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <AssignDeliveryMan />
          </ProtectedRoute>
        ),
      },

      {
        path: "/delivery/add-delivery-men",
        element: (
          <ProtectedRoute
            allowedRoles={["owner"]}
          >
            <AddDeliveryMen />
          </ProtectedRoute>
        ),
      },

      {
        path: "/delivery/track-delivery-men",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
            ]}
          >
            <TrackDeliveryMen />
          </ProtectedRoute>
        ),
      },

      {
        path: "/report",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
              "admin",
            ]}
          >
            <ReportPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/reports/:shopId",
        element: (
          <ProtectedRoute
            allowedRoles={[
              "owner",
              "manager",
              "admin",
            ]}
          >
            <ReportTable />
          </ProtectedRoute>
        ),
      },

      {
        path: "/management",
        element: (
          <ProtectedRoute
            allowedRoles={["owner"]}
          >
            <ManagementPage />
          </ProtectedRoute>
        ),
      },

      {
        path: "/setting",
        element: (
          <ProtectedRoute
            allowedRoles={["owner"]}
          >
            <SettingPage />
          </ProtectedRoute>
        ),
      },
    ],
  },
]);

export default router;