import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAlert } from "../../AlertContext";

export default function DeliFeesTab() {
  const { showAlert } = useAlert();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [deliFees, setDeliFees] = useState(0);
  const [inputValue, setInputValue] = useState("");

  // ================= FETCH =================
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await axios.get(
          "http://38.60.244.137:3000/open-server"
        );

        if (res.data?.data?.deli_fees !== undefined) {
          setDeliFees(res.data.data.deli_fees);
          setInputValue(res.data.data.deli_fees);
        }
      } catch (err) {
        console.error(err);
        showAlert("Failed to load delivery fees", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [showAlert]);

  // ================= SAVE =================
  const handleSave = async () => {
    if (inputValue === "" || isNaN(inputValue)) {
      showAlert("Invalid delivery fee", "warning");
      return;
    }

    setSaving(true);

    try {
      const res = await axios.patch(
        "http://38.60.244.137:3000/deli-fees",
        {
          deli_fees: Number(inputValue),
        }
      );

      if (res.data?.message) {
        showAlert(res.data.message, "success");
      }

      // update UI from response
      if (res.data?.deli_fees !== undefined) {
        setDeliFees(res.data.deli_fees);
        setInputValue(res.data.deli_fees);
      }
    } catch (err) {
      console.error(err);
      showAlert(
        err.response?.data?.message || "Update failed",
        "error"
      );
    } finally {
      setSaving(false);
    }
  };

  // ================= UI =================
  if (loading) {
    return (
      <div className="p-6 text-gray-400 animate-pulse">
        Loading delivery fees...
      </div>
    );
  }

  return (
    <div className="max-w-xl p-6 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl text-white">
      {/* TITLE */}
      <h2 className="text-xl font-bold mb-6 text-purple-400">
        Delivery Fees Settings
      </h2>

      {/* CURRENT VALUE */}
      <div className="mb-6">
        <p className="text-sm text-gray-400">Current Delivery Fee</p>
        <p className="text-2xl font-bold text-white">
          {deliFees.toLocaleString()} Ks
        </p>
      </div>

      {/* INPUT */}
      <div className="mb-6">
        <label className="text-sm text-gray-400 block mb-2">
          Update Delivery Fee
        </label>

        <input
          type="number"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="
            w-full px-4 py-3 rounded-xl
            bg-neutral-900 border border-neutral-700
            text-white outline-none
            focus:border-purple-500
          "
        />
      </div>

      {/* BUTTON */}
      <button
        onClick={handleSave}
        disabled={saving}
        className="
          w-full py-3 rounded-xl font-semibold
          bg-gradient-to-r from-purple-600 to-indigo-500
          hover:opacity-90 transition
          disabled:opacity-50
        "
      >
        {saving ? "Saving..." : "Update Delivery Fee"}
      </button>
    </div>
  );
}