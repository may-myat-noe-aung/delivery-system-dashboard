
// import React, { useEffect, useMemo, useState } from "react";
// import {
//   Store,
//   Utensils,
//   ChevronDown,
//   ChevronUp,
//   Search,
// } from "lucide-react";

// export default function ShopMenus() {
//   const [shops, setShops] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [openShop, setOpenShop] = useState(null);
//   const [search, setSearch] = useState("");

//   // Pagination
//   const [page, setPage] = useState(1);
//   const [pageSize, setPageSize] = useState(6);

//   /* ================= RESPONSIVE PAGE SIZE ================= */
//   useEffect(() => {
//     const updateSize = () => {
//       if (window.innerWidth >= 1536) {
//         setPageSize(8);
//       } else if (window.innerWidth >= 1280) {
//         setPageSize(6);
//       } else if (window.innerWidth >= 768) {
//         setPageSize(4);
//       } else {
//         setPageSize(3);
//       }
//     };

//     updateSize();
//     window.addEventListener("resize", updateSize);

//     return () => window.removeEventListener("resize", updateSize);
//   }, []);

//   /* ================= FETCH ================= */
//   useEffect(() => {
//     const fetchShops = async () => {
//       try {
//         const res = await fetch(
//           "http://38.60.244.137:3000/system-menu-branches"
//         );

//         const result = await res.json();

//         if (result.success) {
//           setShops(result.data);
//         }
//       } catch (err) {
//         console.error(err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchShops();
//   }, []);

//   /* ================= SEARCH ================= */
//   const filteredShops = useMemo(() => {
//     if (!search.trim()) return shops;

//     const keyword = search.toLowerCase();

//     return shops.filter(
//       (shop) =>
//         shop.shop_name.toLowerCase().includes(keyword) ||
//         shop.id.toLowerCase().includes(keyword)
//     );
//   }, [shops, search]);

//   /* ================= PAGINATION ================= */
//   const totalPages = Math.ceil(
//     filteredShops.length / pageSize
//   );

//   const paginatedShops = filteredShops.slice(
//     (page - 1) * pageSize,
//     page * pageSize
//   );

//   /* ================= LOADING ================= */
//   if (loading) {
//     return (
//       <div>
//         <div className="h-12 w-72 rounded-xl bg-white/5 animate-pulse mb-6" />

//         <div className="grid md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-5">
//           {[...Array(6)].map((_, i) => (
//             <div
//               key={i}
//               className="
//                 h-40
//                 rounded-3xl
//                 bg-white/5
//                 border border-white/10
//                 animate-pulse
//               "
//             />
//           ))}
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div>
//       {/* ================= HEADER ================= */}
//       <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
//         <div>
//           <h2 className="text-2xl font-bold text-white">
//             Shop Menus
//           </h2>

//           <p className="text-slate-400 text-sm mt-1">
//             Total Shops : {filteredShops.length}
//           </p>
//         </div>

//         {/* SEARCH */}
//         <div className="relative w-full md:w-80">
//           <Search
//             className="
//               absolute left-4 top-1/2
//               -translate-y-1/2
//               text-slate-400
//               w-5 h-5
//             "
//           />

//           <input
//             type="text"
//             placeholder="Search by Shop Name or ID..."
//             value={search}
//             onChange={(e) => {
//               setSearch(e.target.value);
//               setPage(1);
//             }}
//             className="
//               w-full
//               bg-slate-900/60
//               border border-slate-700
//               rounded-2xl
//               pl-12
//               pr-4
//               py-3
//               text-white
//               placeholder:text-slate-500
//               outline-none
//               focus:border-indigo-500
//             "
//           />
//         </div>
//       </div>

//       {/* ================= NO DATA ================= */}
//       {paginatedShops.length === 0 ? (
//         <div className="text-center text-slate-400 py-10">
//           No shops found.
//         </div>
//       ) : (
//         <>
//           {/* ================= CARDS ================= */}
//           <div className="grid md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-5">
//             {paginatedShops.map((shop) => {
//               const totalPrice = shop.menus.reduce(
//                 (sum, item) => sum + item.price,
//                 0
//               );

//               const isOpen = openShop === shop.id;

//               return (
//                 <div
//                   key={shop.id}
//                   className="
//                     rounded-3xl
//                     border border-white/10
//                     bg-white/5
//                     backdrop-blur-xl
//                     overflow-hidden
//                   "
//                 >
//                   {/* CARD HEADER */}
//                   <div
//                     className="p-5 cursor-pointer"
//                     onClick={() =>
//                       setOpenShop(
//                         isOpen ? null : shop.id
//                       )
//                     }
//                   >
//                     <div className="flex justify-between">
//                       <div>
//                         <div className="flex gap-3">
//                           <div
//                             className="
//                               w-12 h-12
//                               rounded-2xl
//                               bg-indigo-500/20
//                               flex items-center justify-center
//                             "
//                           >
//                             <Store className="w-6 h-6 text-indigo-300" />
//                           </div>

//                           <div>
//                             <h3 className="text-white font-semibold text-lg">
//                               {shop.shop_name}
//                             </h3>

//                             <p className="text-slate-400 text-sm">
//                               {shop.id}
//                             </p>
//                           </div>
//                         </div>

//                         <div className="flex gap-6 mt-4">
//                           <div>
//                             <p className="text-xs text-slate-400">
//                               Menus
//                             </p>

//                             <p className="text-white font-semibold">
//                               {shop.menus.length}
//                             </p>
//                           </div>

//                           <div>
//                             <p className="text-xs text-slate-400">
//                               Total Price
//                             </p>

//                             <p className="text-emerald-400 font-semibold">
//                               {totalPrice.toLocaleString()} Ks
//                             </p>
//                           </div>
//                         </div>
//                       </div>

//                       {isOpen ? (
//                         <ChevronUp className="text-slate-400" />
//                       ) : (
//                         <ChevronDown className="text-slate-400" />
//                       )}
//                     </div>
//                   </div>

//                   {/* MENUS */}
//                   {isOpen && (
//                     <div className="border-t border-white/10 p-4">
//                       {shop.menus.length === 0 ? (
//                         <div className="text-center py-6 text-slate-400">
//                           No menu available
//                         </div>
//                       ) : (
//                         <div className="space-y-3 max-h-72 overflow-y-auto">
//                           {shop.menus.map((menu) => (
//                             <div
//                               key={menu.menu_id}
//                               className="
//                                 flex justify-between items-center
//                                 bg-white/5
//                                 rounded-2xl
//                                 p-3
//                                 border border-white/5
//                               "
//                             >
//                               <div className="flex gap-3">
//                                 <div
//                                   className="
//                                     w-10 h-10
//                                     rounded-xl
//                                     bg-emerald-500/20
//                                     flex items-center justify-center
//                                   "
//                                 >
//                                   <Utensils className="w-5 h-5 text-emerald-300" />
//                                 </div>

//                                 <div>
//                                   <p className="text-white font-medium">
//                                     {menu.menu_name}
//                                   </p>

//                                   <p className="text-xs text-slate-400">
//                                     {menu.menu_id}
//                                   </p>
//                                 </div>
//                               </div>

//                               <p className="text-yellow-400 font-semibold">
//                                 {menu.price.toLocaleString()} Ks
//                               </p>
//                             </div>
//                           ))}
//                         </div>
//                       )}
//                     </div>
//                   )}
//                 </div>
//               );
//             })}
//           </div>

//           {/* ================= PAGINATION ================= */}
//           {totalPages > 0 && (
//             <div className="flex flex-col md:flex-row justify-between px-2 pt-6 text-sm text-slate-400 gap-4 mb-6">
//               <p>
//                 Page {page} of {totalPages}
//               </p>

//               <div className="flex gap-2 flex-wrap">
//                 {/* PREV */}
//                 <button
//                   disabled={page === 1}
//                   onClick={() =>
//                     setPage(Math.max(1, page - 1))
//                   }
//                   className={`px-3 py-1 rounded-md border border-slate-700 ${
//                     page === 1
//                       ? "text-slate-500 cursor-not-allowed"
//                       : "text-indigo-400 hover:bg-slate-800"
//                   }`}
//                 >
//                   Prev
//                 </button>

//                 {/* PAGE NUMBER */}
//                 {Array.from(
//                   { length: totalPages },
//                   (_, i) => i + 1
//                 ).map((n) => (
//                   <button
//                     key={n}
//                     onClick={() => setPage(n)}
//                     className={`px-3 py-1 rounded-md border border-slate-700 ${
//                       page === n
//                         ? "bg-indigo-300 text-black font-semibold"
//                         : "text-indigo-300 hover:bg-slate-800"
//                     }`}
//                   >
//                     {n}
//                   </button>
//                 ))}

//                 {/* NEXT */}
//                 <button
//                   disabled={page === totalPages}
//                   onClick={() =>
//                     setPage(
//                       Math.min(
//                         totalPages,
//                         page + 1
//                       )
//                     )
//                   }
//                   className={`px-3 py-1 rounded-md border border-slate-700 ${
//                     page === totalPages
//                       ? "text-slate-500 cursor-not-allowed"
//                       : "text-indigo-400 hover:bg-slate-800"
//                   }`}
//                 >
//                   Next
//                 </button>
//               </div>
//             </div>
//           )}
//         </>
//       )}
//     </div>
//   );
// }

import React, { useEffect, useMemo, useState } from "react";
import {
  Store,
  Utensils,
  ChevronDown,
  ChevronUp,
  Search,
} from "lucide-react";

export default function ShopMenus() {
  const [shops, setShops] = useState([]);
  const [loading, setLoading] = useState(true);

  // ✅ NEW STATES (MODAL)
  const [selectedShop, setSelectedShop] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const [search, setSearch] = useState("");

  // Pagination
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(6);

  /* ================= RESPONSIVE PAGE SIZE ================= */
  useEffect(() => {
    const updateSize = () => {
      if (window.innerWidth >= 1536) {
        setPageSize(8);
      } else if (window.innerWidth >= 1280) {
        setPageSize(6);
      } else if (window.innerWidth >= 768) {
        setPageSize(4);
      } else {
        setPageSize(3);
      }
    };

    updateSize();
    window.addEventListener("resize", updateSize);

    return () => window.removeEventListener("resize", updateSize);
  }, []);

  /* ================= FETCH ================= */
  // useEffect(() => {
  //   const fetchShops = async () => {
  //     try {
  //       const res = await fetch(
  //         "http://38.60.244.137:3000/system-menu-branches"
  //       );

  //       const result = await res.json();

  //       if (result.success) {
  //         setShops(result.data);
  //       }
  //     } catch (err) {
  //       console.error(err);
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   fetchShops();
  // }, []);
useEffect(() => {
  const fetchShops = async () => {
    try {
      const res = await fetch(
        "http://38.60.244.137:3000/system-menu-branches"
      );

      const result = await res.json();

      if (result.success) {
        setShops(result.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // First load
  fetchShops();

  // Refresh every 1 second
  const interval = setInterval(() => {
    fetchShops();
  }, 1000);

  return () => clearInterval(interval);
}, []);
  /* ================= SEARCH ================= */
  const filteredShops = useMemo(() => {
    if (!search.trim()) return shops;

    const keyword = search.toLowerCase();

    return shops.filter(
      (shop) =>
        shop.shop_name.toLowerCase().includes(keyword) ||
        shop.id.toLowerCase().includes(keyword)
    );
  }, [shops, search]);

  /* ================= PAGINATION ================= */
  const totalPages = Math.ceil(filteredShops.length / pageSize);

  const paginatedShops = filteredShops.slice(
    (page - 1) * pageSize,
    page * pageSize
  );

  /* ================= LOADING ================= */
  if (loading) {
    return (
      <div>
        <div className="h-12 w-72 rounded-xl bg-white/5 animate-pulse mb-6" />

        <div className="grid md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-5">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="h-40 rounded-3xl bg-white/5 border border-white/10 animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* ================= HEADER ================= */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white">Shop Menus</h2>
          <p className="text-slate-400 text-sm mt-1">
            Total Shops : {filteredShops.length}
          </p>
        </div>

        {/* SEARCH */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />

          <input
            type="text"
            placeholder="Search by Shop Name or ID..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-900/60 border border-slate-700 rounded-2xl pl-12 pr-4 py-3 text-white"
          />
        </div>
      </div>

      {/* ================= CARDS ================= */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-5">
        {paginatedShops.map((shop) => {
          const menus = shop.menus || [];
          const totalPrice = menus.reduce(
            (sum, item) => sum + (item.price || 0),
            0
          );

          return (
            <div
              key={shop.id}
              className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl overflow-hidden"
            >
              {/* CARD HEADER */}
              <div className="p-5">
                <div className="flex justify-between">
                  <div className="flex gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 flex items-center justify-center">
                      <Store className="w-6 h-6 text-indigo-300" />
                    </div>

                    <div>
                      <h3 className="text-white font-semibold text-lg">
                        {shop.shop_name}
                      </h3>
                      <p className="text-slate-400 text-sm">{shop.id}</p>
                    </div>
                  </div>

               
                </div>

                <div className="flex gap-6 mt-4 items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-400">Menus</p>
                    <p className="text-white font-semibold">
                      {menus.length}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-slate-400">Total Price</p>
                    <p className="text-emerald-400 font-semibold">
                      {totalPrice.toLocaleString()} Ks
                    </p>
                  </div>
                     {/* ✅ DETAIL BUTTON */}
                  <button
                    onClick={() => {
                      setSelectedShop(shop);
                      setShowModal(true);
                    }}
                    className="px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-xl"
                  >
                    Detail
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ================= MODAL ================= */}
      {showModal && selectedShop && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-slate-900 rounded-2xl w-[90%] md:w-[600px] p-6 relative">

            {/* CLOSE */}
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 text-white"
            >
              ✕
            </button>

            {/* TITLE */}
            <h2 className="text-xl font-bold text-white mb-2">
              {selectedShop.shop_name}
            </h2>

            <p className="text-slate-400 mb-4">
              ID: {selectedShop.id}
            </p>

            {/* MENU LIST */}
            <div className="max-h-80 overflow-y-auto space-y-3">
              {(selectedShop.menus || []).map((menu) => (
                <div
                  key={menu.menu_id}
                  className="flex justify-between bg-white/5 p-3 rounded-xl"
                >
                  <p className="text-white">{menu.menu_name}</p>
                  <p className="text-yellow-400">
                    {menu.price.toLocaleString()} Ks
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= PAGINATION (UNCHANGED) ================= */}
      <div className="flex justify-between px-2 pt-6 text-sm text-slate-400">
        <p>
          Page {page} of {totalPages}
        </p>
      </div>
    </div>
  );
}
