// import React, { useEffect, useState } from "react";
// import {
//   X,
//   Tag,
//   DollarSign,
//   FileText,
//   CheckCircle,
//   Star,
//   CalendarDays,
//   Layers,
// } from "lucide-react";

// // ================= CATEGORY MAP =================
// const categoryMap = {
//   1: "snack",
//   2: "alcoholic",
//   3: "breakfast",
//   4: "cake",
//   5: "coffee",
//   6: "drink",
//   7: "fastfood",
//   8: "lunch",
//   9: "morning",
//   10: "sweets",
// };

// export default function MenuDetailPopup({ menu, onClose }) {
//   const [data, setData] = useState(menu);
//   const [loading, setLoading] = useState(true);

//   // ================= SYNC =================
//   useEffect(() => {
//     if (!menu) return;

//     const t = setTimeout(() => {
//       setData(menu);
//       setLoading(false);
//     }, 200);

//     return () => clearTimeout(t);
//   }, [menu]);

//   if (!menu) return null;

//   // ================= LOADING =================
//   if (loading) {
//     return (
//       <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
//         <p className="text-white">Loading...</p>
//       </div>
//     );
//   }

//   // ================= IMAGE HELPER =================
//   const getPhotoUrl = (type, photo) => {
//     if (!photo) return null;
//     return `http://38.60.244.137:3000/${type}-uploads/${photo}`;
//   };

//   // ================= PRICE FORMAT (FIXED) =================
//   const formatPrices = (prices) => {
//     if (!Array.isArray(prices)) return "-";

//     return prices
//       .map((p) =>
//         typeof p === "object"
//           ? `${p.size}: ${p.price} Ks`
//           : p
//       )
//       .join(" • ");
//   };

//   // ================= CATEGORY FIX =================
//   const getCategory = () => {
//     if (data?.category && data.category !== "launch") {
//       return data.category;
//     }

//     const id = Number(data?.category_id?.split("_C")?.[1]);
//     return categoryMap[id] || "-";
//   };

//   return (
//     <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
//       <div className="bg-gray-900 text-white w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-2xl p-6 relative">

//         {/* CLOSE */}
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 bg-gray-700 p-2 rounded-full"
//         >
//           <X size={20} />
//         </button>

//         {/* TITLE */}
//         <h2 className="text-2xl font-bold text-[#B476FF] mb-4">
//           {data.name}
//         </h2>

//         {/* TOP SECTION */}
//         <div className="grid grid-cols-1 md:grid-cols-5 gap-4">

//           {/* MENU IMAGE */}
//           <div className="col-span-2">
//             {data.photo ? (
//               <img
//                 src={getPhotoUrl("menu", data.photo)}
//                 className="w-full h-[300px] object-cover rounded-xl"
//               />
//             ) : (
//               <div className="h-[300px] flex items-center justify-center bg-gray-800 rounded-xl">
//                 No Image
//               </div>
//             )}
//           </div>

//           {/* INFO */}
//           <div className="col-span-3 bg-gray-800 p-4 rounded-xl">

//             <Info icon={Tag} label="Category" value={getCategory()} />
//             <Info icon={DollarSign} label="Price" value={formatPrices(data.prices)} />
//             <Info icon={FileText} label="Description" value={data.description || "-"} />
//             <Info icon={CheckCircle} label="Orders" value={data.complete_order} />
//             <Info
//               icon={Star}
//               label="Rating"
//               value={`${data.rating} (${data.rating_count})`}
//             />
//             <Info icon={CalendarDays} label="Created" value={data.created_at} />
//             <Info
//               icon={CalendarDays}
//               label="Months"
//               value={data.get_months?.join(", ") || "-"}
//             />

//           </div>
//         </div>

//         {/* RELATED MENU */}
//         <Section title="Related Menu" items={data.relate_menu} type="menu" />

//         {/* INGREDIENTS */}
//         <Section title="Ingredients" items={data.relate_ingredients} type="ingredient" />

//       </div>
//     </div>
//   );
// }

// /* ================= INFO ================= */
// const Info = ({ icon: Icon, label, value }) => (
//   <div className="flex items-center gap-2 mb-2">
//     <Icon className="text-[#B476FF]" size={18} />
//     <div>
//       <p className="text-sm text-gray-400">{label}</p>
//       <p className="text-sm">{value}</p>
//     </div>
//   </div>
// );

// /* ================= SECTION ================= */
// const Section = ({ title, items = [], type }) => {
//   const getPhotoUrl = (photo) => {
//     if (!photo) return null;

//     const folder =
//       type === "ingredient"
//         ? "ingredients-uploads"
//         : "menu-uploads";

//     return `http://38.60.244.137:3000/${folder}/${photo}`;
//   };

//   return (
//     <div className="mt-6">
//       <h3 className="text-[#B476FF] font-semibold text-lg mb-3">
//         {title}
//       </h3>

//       {Array.isArray(items) && items.length > 0 ? (
//         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

//           {items.map((item, idx) => (
//             <div
//               key={idx}
//               className="flex gap-3 bg-gray-800 p-3 rounded-lg"
//             >

//               <img
//                 src={getPhotoUrl(item.photo)}
//                 className="w-20 h-20 object-cover rounded-lg"
//                 alt={item.name}
//               />

//               <div>
//                 <p className="font-bold text-[#B476FF]">
//                   {item.name}
//                 </p>

//                 {/* SAFE PRICE */}
//                 <p className="text-sm text-gray-300">
//                   {Array.isArray(item.prices)
//                     ? item.prices
//                         .map((p) => `${p.size}: ${p.price}`)
//                         .join(" • ")
//                     : item.prices || "-"}
//                 </p>

//                 {item.category && (
//                   <p className="text-xs text-gray-400">
//                     {item.category}
//                   </p>
//                 )}

//               </div>
//             </div>
//           ))}

//         </div>
//       ) : (
//         <p className="text-gray-400">No {title}</p>
//       )}
//     </div>
//   );
// };
import React, { useEffect, useState } from "react";
import {
  X,
  Tag,
  DollarSign,
  FileText,
  CheckCircle,
  Star,
  CalendarDays,
  Layers,
} from "lucide-react";

// ================= CATEGORY MAP =================
const categoryMap = {
  1: "snack",
  2: "alcoholic",
  3: "breakfast",
  4: "cake",
  5: "coffee",
  6: "drink",
  7: "fastfood",
  8: "lunch",
  9: "morning",
  10: "sweets",
};

export default function MenuDetailPopup({ menu, onClose }) {
  const [data, setData] = useState(menu);
  const [loading, setLoading] = useState(true);

  // ================= SYNC =================
  useEffect(() => {
    if (!menu) return;

    const t = setTimeout(() => {
      setData(menu);
      setLoading(false);
    }, 200);

    return () => clearTimeout(t);
  }, [menu]);

  if (!menu) return null;

  // ================= LOADING =================
  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50">
        <p className="text-white text-lg animate-pulse">Loading...</p>
      </div>
    );
  }

  // ================= IMAGE HELPER =================
  const getPhotoUrl = (type, photo) => {
    if (!photo) return null;
    return `http://38.60.244.137:3000/${type}-uploads/${photo}`;
  };

  // ================= PRICE FORMAT =================
  const formatPrices = (prices) => {
    if (!Array.isArray(prices)) return "-";

    return prices
      .map((p) =>
        typeof p === "object"
          ? `${p.size}: ${p.price} Ks`
          : p
      )
      .join(" • ");
  };

  // ================= CATEGORY FIX =================
  const getCategory = () => {
    if (data?.category && data.category !== "launch") {
      return data.category;
    }

    const id = Number(data?.category_id?.split("_C")?.[1]);
    return categoryMap[id] || "-";
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xl flex items-center justify-center z-50 p-4">
      
      <div className="bg-gradient-to-b from-gray-900 to-gray-950 text-white w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-2xl p-6 relative shadow-2xl border border-gray-700">

        {/* CLOSE */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 bg-gray-800 hover:bg-red-500 transition p-2 rounded-full shadow-lg"
        >
          <X size={20} />
        </button>

        {/* TITLE */}
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-6">
          {data.name}
        </h2>

        {/* TOP SECTION */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">

          {/* IMAGE */}
          <div className="col-span-2">
            {data.photo ? (
              <img
                src={getPhotoUrl("menu", data.photo)}
                className="w-full h-[320px] object-cover rounded-2xl shadow-lg border border-gray-700"
              />
            ) : (
              <div className="h-[320px] flex items-center justify-center bg-gray-800 rounded-2xl border border-gray-700">
                No Image
              </div>
            )}
          </div>

          {/* INFO */}
          <div className="col-span-3 bg-gray-900/60 backdrop-blur-md p-5 rounded-2xl border border-gray-700 shadow-lg space-y-3">

            <Info icon={Tag} label="Category" value={getCategory()} />
            <Info icon={DollarSign} label="Price" value={formatPrices(data.prices)} />
            <Info icon={FileText} label="Description" value={data.description || "-"} />
            <Info icon={CheckCircle} label="Orders" value={data.complete_order} />
            <Info icon={Star} label="Rating" value={`${data.rating} (${data.rating_count})`} />
            <Info icon={CalendarDays} label="Created" value={data.created_at} />
            <Info icon={CalendarDays} label="Months" value={data.get_months?.join(", ") || "-"} />

          </div>
        </div>

        {/* RELATED MENU */}
        <Section title="Related Menu" items={data.relate_menu} type="menu" />

        {/* INGREDIENTS */}
        <Section title="Ingredients" items={data.relate_ingredients} type="ingredient" />

      </div>
    </div>
  );
}

/* ================= INFO ================= */
const Info = ({ icon: Icon, label, value }) => (
  <div className="flex items-start gap-3 p-2 rounded-lg hover:bg-gray-800/40 transition">
    <Icon className="text-purple-400 mt-1" size={18} />
    <div>
      <p className="text-xs text-gray-400 uppercase tracking-wide">{label}</p>
      <p className="text-sm font-medium text-gray-100">{value}</p>
    </div>
  </div>
);

/* ================= SECTION ================= */
const Section = ({ title, items = [], type }) => {
  const getPhotoUrl = (photo) => {
    if (!photo) return null;

    const folder =
      type === "ingredient"
        ? "ingredients-uploads"
        : "menu-uploads";

    return `http://38.60.244.137:3000/${folder}/${photo}`;
  };

  return (
    <div className="mt-8">
      
      <h3 className="text-xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-4">
        {title}
      </h3>

      {Array.isArray(items) && items.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

          {items.map((item, idx) => (
            <div
              key={idx}
              className="flex gap-4 bg-gray-900/60 hover:bg-gray-800/70 transition p-4 rounded-xl border border-gray-700 shadow-md"
            >

              <img
                src={getPhotoUrl(item.photo)}
                className="w-20 h-20 object-cover rounded-lg border border-gray-700"
                alt={item.name}
              />

              <div className="flex-1">
                <p className="font-bold text-purple-300">
                  {item.name}
                </p>

                <p className="text-sm text-gray-300 mt-1">
                  {Array.isArray(item.prices)
                    ? item.prices
                        .map((p) => `${p.size}: ${p.price}`)
                        .join(" • ")
                    : item.prices || "-"}
                </p>

                {item.category && (
                  <span className="inline-block mt-2 text-xs px-2 py-1 bg-purple-500/20 text-purple-300 rounded-full">
                    {item.category}
                  </span>
                )}

              </div>
            </div>
          ))}

        </div>
      ) : (
        <p className="text-gray-500 italic">No {title}</p>
      )}
    </div>
  );
};