import React, { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Store,
  Truck,
  BarChart2,
  Users,
  Settings,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import logo from "../assets/images/pwyzay.jpg";
import { LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAlert } from "../AlertContext";

const Aside = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { showAlert, confirm } = useAlert();
  const [collapsed, setCollapsed] = useState(() => {
    const saved = localStorage.getItem("sidebar-collapsed");
    return saved ? JSON.parse(saved) : false;
  });

  const role = localStorage.getItem("role");

  const handleLogout = async () => {
    const ok = await confirm("Are you sure you want to logout?");

    if (!ok) return;

    localStorage.clear();

    showAlert("Logged out successfully!", "success");

    navigate("/login");
  };
  useEffect(() => {
    localStorage.setItem("sidebar-collapsed", JSON.stringify(collapsed));
  }, [collapsed]);

  const isDeliveryRoute =
    location.pathname.startsWith("/delivery") ||
    location.pathname.startsWith("/orders");

  const [isDeliveryOpen, setIsDeliveryOpen] = useState(isDeliveryRoute);

  useEffect(() => {
    setIsDeliveryOpen(isDeliveryRoute);
  }, [location.pathname]);

  const navItems = [
    {
      label: "Dashboard",
      icon: LayoutDashboard,
      to: "/",
      roles: ["owner", "manager", "admin"],
    },

    {
      label: "Shop",
      icon: Store,
      to: "/shop",
      roles: ["owner", "manager"],
    },

    {
      label: "Delivery",
      icon: Truck,
      roles: ["owner", "manager"],
      children: [
        {
          label: "Assign Delivery",
          to: "/orders/assignment",
        },
        ...(role === "owner"
          ? [
              {
                label: "Add Delivery Man",
                to: "/delivery/add-delivery-men",
              },
            ]
          : []),
        {
          label: "Track Delivery Man",
          to: "/delivery/track-delivery-men",
        },
      ],
    },

    {
      label: "Report",
      icon: BarChart2,
      to: "/report",
      roles: ["owner", "manager", "admin"],
    },

    {
      label: "Management",
      icon: Users,
      to: "/management",
      roles: ["owner"],
    },

    {
      label: "Settings",
      icon: Settings,
      to: "/setting",
      roles: ["owner"],
    },
  ];
  return (
    <aside
      className={`
      h-screen
    bg-gray-900
      text-gray-300
      flex flex-col
      shadow-xl
      transition-all duration-300
      ${collapsed ? "w-20" : "w-64 2xl:w-72 border-r border-gray-800"}
    `}
    >
      {/* LOGO + TOGGLE */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800/40">
        {!collapsed && (
          <div className="flex items-center gap-3">
            <img
              src={logo}
              alt="logo"
              className="w-10 h-10 rounded-xl ring-1 ring-purple-500/20"
            />

            <h1 className="text-lg font-bold bg-gradient-to-r from-purple-400 to-fuchsia-500 bg-clip-text text-transparent">
            Pwy Zay
            </h1>
          </div>
        )}

        {collapsed && (
          <img src={logo} alt="logo" className="w-9 h-9 rounded-xl mx-auto" />
        )}

        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-gray-400 hover:text-white"
        >
          {collapsed ? "»" : "«"}
        </button>
      </div>

      {/* NAV */}
      <nav className="flex-1 px-2 py-4 space-y-2 overflow-y-auto">
        {navItems
          .filter((item) => {
            if (!item.roles) return true;
            return item.roles.includes(role);
          })
          .map(({ label, icon: Icon, to, children }) => {
            // NORMAL LINK
            if (!children) {
              return (
                <NavLink
                  key={label}
                  to={to}
                  className={({ isActive }) =>
                    `
                  flex items-center gap-3
                  px-3 py-3 rounded-xl
                  transition-colors duration-200
                  relative group
                  ${
                    isActive
                      ? "bg-purple-600/20 text-[#B476FF] "
                      : "text-gray-400 hover:bg-gray-800/60 hover:text-white"
                  }
                `
                  }
                >
                  <Icon className="w-5 h-5" />

                  {!collapsed && (
                    <span className="text-sm font-medium">{label}</span>
                  )}

                  {/* Tooltip when collapsed */}
                  {collapsed && (
                    <span
                      className="
                      absolute left-16
                      bg-black text-white text-xs
                      px-2 py-1 rounded
                      opacity-0 group-hover:opacity-100
                      transition
                      whitespace-nowrap
                    "
                    >
                      {label}
                    </span>
                  )}
                </NavLink>
              );
            }

            // DROPDOWN
            return (
              <div key={label} className="space-y-1">
                <button
                  onClick={() => setIsDeliveryOpen(!isDeliveryOpen)}
                  className="
                  w-full flex items-center gap-3 justify-between
                  px-3 py-3 rounded-xl
                  text-gray-400 hover:bg-gray-800/60 hover:text-white
                "
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5" />

                    {!collapsed && (
                      <span className="text-sm font-medium">{label}</span>
                    )}
                  </div>

                  {!collapsed &&
                    (isDeliveryOpen ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    ))}
                </button>

                {/* SUB MENU */}
                {!collapsed && (
                  <div
                    className={`
                    ml-6 pl-3 border-l border-purple-500/10
                    flex flex-col gap-1
                    transition-all duration-200 ease-out hover:translate-x-0.5
                    overflow-hidden
                    ${isDeliveryOpen ? "max-h-40 mt-2" : "max-h-0"}
                  `}
                  >
                    {children.map(({ label: childLabel, to: childTo }) => (
                      <NavLink
                        key={childLabel}
                        to={childTo}
                        className={({ isActive }) =>
                          `
                        text-sm px-3 py-2 rounded-lg transition-colors
                        ${
                          isActive
                            ? "text-purple-400 bg-purple-500/10"
                            : "text-gray-500 hover:text-white hover:bg-gray-800/60"
                        }
                      `
                        }
                      >
                        {childLabel}
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
      </nav>

      {/* LOGOUT */}
      <div className="p-3 border-t border-gray-800/40">
        <button
          onClick={handleLogout}
          className="
          w-full flex items-center justify-center gap-3
          px-3 py-3 rounded-xl
          bg-red-500/10 text-red-400
          hover:bg-red-500/20
          transition-colors duration-200
        "
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
};

export default Aside;
// import React, { useEffect, useState } from "react";
// import {
//   LayoutDashboard,
//   Store,
//   Truck,
//   BarChart2,
//   Users,
//   Settings,

// } from "lucide-react";
// import { NavLink, useLocation } from "react-router-dom";
// import logo from "../assets/images/logo/logo.png";
// import { LogOut } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import { useAlert } from "../AlertContext";

// const Aside = () => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const [openMenu, setOpenMenu] = useState(null);

// const { showAlert, confirm } = useAlert();
// const [collapsed, setCollapsed] = useState(() => {
//   const saved = localStorage.getItem("sidebar-collapsed");
//   return saved ? JSON.parse(saved) : false;
// });

//   const role = localStorage.getItem("role");

//   const handleLogout = async () => {
//   const ok = await confirm(
//     "Are you sure you want to logout?"
//   );

//   if (!ok) return;

//   localStorage.clear();

//   showAlert("Logged out successfully!", "success");

//   navigate("/login");
// };
// useEffect(() => {
//   localStorage.setItem("sidebar-collapsed", JSON.stringify(collapsed));
// }, [collapsed]);

//   const isDeliveryRoute =
//     location.pathname.startsWith("/delivery") ||
//     location.pathname.startsWith("/orders");

//   const [isDeliveryOpen, setIsDeliveryOpen] =
//     useState(isDeliveryRoute);

//   useEffect(() => {
//     setIsDeliveryOpen(isDeliveryRoute);
//   }, [location.pathname]);

//   const navItems = [
//     {
//       label: "Dashboard",
//       icon: LayoutDashboard,
//       to: "/",
//       roles: ["owner", "manager", "admin"],
//     },

//     {
//       label: "Shop",
//       icon: Store,
//       to: "/shop",
//       roles: ["owner", "manager"],
//     },

//     {
//       label: "Delivery",
//       icon: Truck,
//       roles: ["owner", "manager"],
//       children: [
//         {
//           label: "Assign Delivery",
//           to: "/orders/assignment",
//         },
//         ...(role === "owner"
//           ? [
//               {
//                 label: "Add Delivery Man",
//                 to: "/delivery/add-delivery-men",
//               },
//             ]
//           : []),
//         {
//           label: "Track Delivery Man",
//           to: "/delivery/track-delivery-men",
//         },
//       ],
//     },

//     {
//       label: "Report",
//       icon: BarChart2,
//       to: "/report",
//       roles: ["owner", "manager", "admin"],
//     },

//     {
//       label: "Management",
//       icon: Users,
//       to: "/management",
//       roles: ["owner"],
//     },

//     {
//       label: "Settings",
//       icon: Settings,
//       to: "/setting",
//       roles: ["owner"],
//     },
//   ];
// return (
// <aside
//   className={`
//     h-screen
//     flex flex-col
//     text-gray-300
//     bg-gradient-to-b from-[#0b0f19] via-[#0a0e18] to-[#070b14]
//     border-r border-white/5
//     shadow-[0_0_40px_rgba(0,0,0,0.6)]
//     backdrop-blur-xl
//     transition-all duration-300 ease-in-out
//     ${collapsed ? "w-20" : "w-72"}
//   `}
// >
//   {/* HEADER */}
// <div className="flex items-center justify-between p-4 border-b border-white/5">
//   <div className="flex items-center gap-3">
//     <img
//       src={logo}
//       className="
//         w-10 h-10 rounded-xl
//         ring-1 ring-purple-500/30
//         shadow-md
//       "
//     />

//     {!collapsed && (
//       <h1 className="
//         text-lg font-bold
//         bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400
//         bg-clip-text text-transparent
//       ">
//         Blahhh
//       </h1>
//     )}
//   </div>

//   <button
//     className="
//       w-8 h-8 flex items-center justify-center
//       rounded-lg
//       bg-white/5 hover:bg-white/10
//       border border-white/5
//       text-gray-300 hover:text-white
//       transition
//     "
//     onClick={() => setCollapsed(!collapsed)}
//   >
//     {collapsed ? "»" : "«"}
//   </button>
// </div>

// {/* NAV */}
// <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">

//   {navItems
//     .filter((item) => !item.roles || item.roles.includes(role))
//     .map(({ label, icon: Icon, to, children }) => {
//       const isOpen = openMenu === label;

//       // NORMAL ITEM
//       if (!children) {
//         return (
//    <NavLink to={to}>
//   {({ isActive }) => (
//     <div
//       className={`
//         relative flex items-center gap-3
//         px-3 py-3 rounded-xl
//         transition
//         ${
//           isActive
//             ? "bg-white/5 text-purple-300"
//             : "text-gray-400 hover:bg-white/5 hover:text-white"
//         }
//       `}
//     >
//       <span
//         className={`
//           absolute left-0 top-2 bottom-2 w-1 rounded-r
//           bg-gradient-to-b from-purple-500 to-fuchsia-500
//           ${isActive ? "opacity-100" : "opacity-0"}
//         `}
//       />
//       <Icon className="w-5 h-5" />
//       {!collapsed && <span>{label}</span>}
//     </div>
//   )}
// </NavLink>
//         );
//       }

//       // DROPDOWN
//       return (
//         <div key={label} className="space-y-1">
//           <button
//             onClick={() =>
//               setOpenMenu(isOpen ? null : label)
//             }
//             className="
//               w-full flex items-center justify-between
//               px-3 py-3 rounded-xl
//               text-gray-400
//               hover:bg-white/5 hover:text-white
//               transition-all duration-200 ease-out hover:translate-x-0.5
//               group
//             "
//           >
//             <div className="flex items-center gap-3">
//               <Icon className="w-5 h-5 group-hover:text-white transition" />

//               {!collapsed && (
//                 <span className="text-sm font-medium">
//                   {label}
//                 </span>
//               )}
//             </div>

//             {!collapsed && (
//               <span className="text-xs text-gray-500">
//                 {isOpen ? "−" : "+"}
//               </span>
//             )}
//           </button>

//           {/* SUB MENU */}
//           {!collapsed && (
//             <div
//               className={`
//                 ml-6 pl-3 border-l border-white/10
//                 flex flex-col gap-1

//                 rounded-lg
//                 bg-white/5

//                 overflow-hidden
//                 transition-all duration-300 ease-in-out

//                 ${isOpen ? "max-h-40 mt-2 p-2 opacity-100" : "max-h-0 opacity-0"}
//               `}
//             >
//               {children.map(({ label: childLabel, to }) => (
//                 <NavLink
//                   key={childLabel}
//                   to={to}
//                   className={({ isActive }) => `
//                     text-sm px-3 py-2 rounded-lg
//                     transition-all duration-200 ease-out hover:translate-x-0.5

//                     ${
//                       isActive
//                         ? "bg-purple-500/20 text-purple-200"
//                         : "text-gray-400 hover:text-white hover:bg-white/5"
//                     }
//                   `}
//                 >
//                   {childLabel}
//                 </NavLink>
//               ))}
//             </div>
//           )}
//         </div>
//       );
//     })}
// </nav>

//   {/* LOGOUT */}
//   <div className="p-3 border-t border-gray-800/40">
//     <button
//       onClick={handleLogout}
//       className="
//         w-full flex items-center justify-center gap-3
//         px-3 py-3 rounded-xl
//         bg-red-500/10 text-red-400
//         hover:bg-red-500/20
//         transition
//       "
//     >
//       <LogOut className="w-5 h-5" />
//       {!collapsed && <span>Logout</span>}
//     </button>
//   </div>
// </aside>
// );
// };

// export default Aside;
