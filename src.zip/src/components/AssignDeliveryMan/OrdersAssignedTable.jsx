// import React, { useEffect, useState, useMemo } from "react";
// import { Download, Search } from "lucide-react";
// import AssignedOrdersPopup from "./AssignedOrdersPopup";

// export default function OrdersAssignedTable() {
//   const [deliveryMen, setDeliveryMen] = useState([]);
//   const [selected, setSelected] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   const [page, setPage] = useState(1);
//   const [pageSize] = useState(5);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");
//   const [csvMessage, setCsvMessage] = useState("");

// useEffect(() => {
//   let intervalId;

//   const fetchData = async () => {
//     try {
//       const res = await fetch("http://38.60.244.137:3000/connected-orders");
//       const data = await res.json();
//       if (data.success) {
//         setDeliveryMen(data.data || []);
//         setError("");
//       } else {
//         setError("Failed to fetch connected orders.");
//       }
//     } catch (err) {
//       setError("Something went wrong.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch immediately once
//   fetchData();

//   // Then fetch every 500ms
//   intervalId = setInterval(fetchData, 500);

//   // Cleanup on unmount
//   return () => clearInterval(intervalId);
// }, []);

//   // 🔍 Filtering
//   const filtered = useMemo(() => {
//     return deliveryMen.filter((dm) => {
//       const matchesSearch =
//         dm.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         dm.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         dm.phone?.toLowerCase().includes(searchTerm.toLowerCase());

//       const hasMatchingDate = dm.orders?.some((order) => {
//         const orderDate = new Date(order.created_at);
//         const fromMatch = fromDate ? orderDate >= new Date(fromDate) : true;
//         const toMatch = toDate ? orderDate <= new Date(toDate) : true;
//         return fromMatch && toMatch;
//       });

//       return matchesSearch && (fromDate || toDate ? hasMatchingDate : true);
//     });
//   }, [deliveryMen, searchTerm, fromDate, toDate]);

//   // Pagination
//   const totalPages = Math.ceil(filtered.length / pageSize);
//   const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);

//   useEffect(() => {
//     if (page > totalPages) setPage(1);
//   }, [filtered]);

//   // 📤 Export
//   const handleExport = () => {
//     const rows = [];

//     filtered.forEach((dm) => {
//       dm.orders.forEach((order) => {
//         rows.push([
//           dm.id,
//           dm.name,
//           dm.email || "-",
//           dm.phone || "-",
//           dm.work_type || "-",
//           // dm.location || "N/A",
//           dm.status || "Unknown",
//           dm.rating ?? 0,
//           dm.total_order ?? 0,
//           dm.assign_order ?? 0,
//           dm.current_orders ?? 0,
//           order.id,
//           order.name,
//           order.type,
//           order.grand_total,
//           order.created_at,
//         ]);
//       });
//     });

//     const csvContent = [
//       [
//         [
//           "Delivery ID",
//           "Delivery Name",
//           "Email",
//           "Phone",
//           "Work Type",
//           // "Location",
//           "Status",
//           "Rating",
//           "Total Orders",
//           "Assigned Orders",
//           "Current Orders",
//           "Order ID",
//           "Customer",
//           "Type",
//           "Total",
//           "Date",
//         ],
//       ],
//       ...rows,
//     ]
//       .map((row) => row.map((field) => `"${field}"`).join(","))
//       .join("\n");

//     const blob = new Blob([csvContent], {
//       type: "text/csv;charset=utf-8;",
//     });

//     const url = URL.createObjectURL(blob);
//     const link = document.createElement("a");
//     link.href = url;
//     link.setAttribute("download", "assigned-orders.csv");
//     document.body.appendChild(link);
//     link.click();
//     document.body.removeChild(link);

//     setCsvMessage("CSV exported successfully!");
//     setTimeout(() => setCsvMessage(""), 2000);
//   };

//   return (
//     <div className=" text-white mt-8 mb-8">
//       {csvMessage && (
//         <div className="mb-2 text-center py-2 px-3 bg-green-600 text-white rounded-md animate-pulse">
//           {csvMessage}
//         </div>
//       )}

//       {/* Header */}
//       <div className="mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
//         <h2 className="text-2xl font-semibold text-[#B476FF]">
//           Orders Assigned Table
//         </h2>

//         <div className="flex flex-col md:flex-row gap-3">
//           <div className="relative">
//             <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-400" />
//             <input
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//               placeholder="Search delivery..."
//               className="rounded-2xl bg-neutral-900 border border-neutral-700 pl-8 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
//             />
//           </div>

//           <button
//             onClick={handleExport}
//             className="flex items-center gap-1 px-3 py-2 rounded-2xl border border-neutral-700 text-sm text-neutral-300 hover:text-white"
//           >
//             <Download size={14} /> Export
//           </button>

//           <input
//             type="date"
//             value={fromDate}
//             onChange={(e) => setFromDate(e.target.value)}
//             className="rounded-2xl bg-purple-500 focus:ring-purple-400 text-white px-3 py-2 text-sm"
//           />

//           <input
//             type="date"
//             value={toDate}
//             onChange={(e) => setToDate(e.target.value)}
//             className="rounded-2xl bg-purple-500 focus:ring-purple-400 text-white px-3 py-2 text-sm"
//           />
//         </div>
//       </div>

//       {/* Table */}
//       <div className="bg-[#1a2030]/80 backdrop-blur-xl border border-slate-700 rounded-3xl shadow-2xl p-6">
//         {loading ? (
//           <div className="text-center text-slate-400 py-10">
//             Loading assigned orders...
//           </div>
//         ) : error ? (
//           <div className="text-center text-red-500 py-10">{error}</div>
//         ) : paginated.length === 0 ? (
//           <div className="text-center text-slate-400 py-10">
//             No assigned orders found.
//           </div>
//         ) : (
//           <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700">
//             <table className="w-full text-sm">
//               <thead className="text-slate-400 border-b border-slate-700">
//                 <tr>
//                   <th className="py-4 text-left">Order ID</th>
//                   {/* <th className="py-4 text-left">User ID</th> */}
//                   <th className="py-4 text-left">Delivery Men</th>
//                   <th className="py-4 text-left">Email</th>
//                   <th className="py-4 text-left">Phone</th>
//                   <th className="py-4 text-left">Work Type</th>
//                   {/* <th className="py-4 text-left">Location</th> */}
//                   <th className="py-4 text-left">Status</th>
//                   <th className="py-4 text-left">Rating</th>
//                   <th className="py-4 text-left">Total Orders</th>
//                   <th className="py-4 text-left">Assigned Orders</th>
//                   <th className="py-4 text-left">Current Orders</th>
//                   {/* <th className="py-4 text-left">Items</th> */}
//                   {/* <th className="py-4 text-left">Total</th> */}
//                   <th className="py-4 text-left">Action</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {paginated.map((dm) => (
//                   <tr
//                     key={dm.id}
//                     className="border-b border-slate-800 hover:bg-slate-800/40 transition"
//                   >
//                     <td className="py-4 font-semibold text-cyan-400">
//                       {dm.id}
//                     </td>
//                     <td className="py-4 font-semibold text-cyan-400">
//                       {dm.name}
//                     </td>

//                     <td className="py-4 text-slate-300">{dm.email || "-"}</td>
//                     <td className="py-4 font-semibold">{dm.phone}</td>
//                     <td className="py-4 text-purple-400">
//                       {dm.work_type || "-"}
//                     </td>
//                     {/* <td className="py-4 text-slate-300">
//                       {dm.location || "N/A"}
//                     </td> */}
//                     <td className="py-4 font-semibold text-yellow-400">
//                       {dm.status || "Unknown"}
//                     </td>
//                     <td className="py-4 text-yellow-400">
//                       ⭐ {dm.rating ?? 0}
//                     </td>
//                     <td className="py-4 text-blue-400">
//                       {dm.total_order ?? 0}
//                     </td>
//                     <td className="py-4 text-purple-400">
//                       {dm.assign_order ?? 0}
//                     </td>
//                     <td className="py-4 text-pink-400">
//                       {dm.current_orders?.length ?? 0}
//                     </td>
                 
//                     <td className="flex gap-2 items-center justify-center py-4">
//                       <button
//                         onClick={() => setSelected(dm)}
//                         className="px-4 py-2 bg-purple-500 hover:bg-purple-600 rounded-xl text-sm"
//                       >
//                         Details
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>

//             {/* Pagination */}
//             <div className="flex justify-between px-4 pt-4 text-sm text-neutral-400">
//               <p>
//                 Page {totalPages === 0 ? 0 : page} of {totalPages}
//               </p>

//               <div className="flex gap-2">
//                 <button
//                   disabled={page === 1}
//                   onClick={() => setPage(page - 1)}
//                   className="px-3 py-1 rounded-md border border-neutral-700"
//                 >
//                   Prev
//                 </button>

//                 <button
//                   disabled={page === totalPages}
//                   onClick={() => setPage(page + 1)}
//                   className="px-3 py-1 rounded-md border border-neutral-700"
//                 >
//                   Next
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>

//       {selected && (
//         <AssignedOrdersPopup
//           delivery={selected}
//           close={() => setSelected(null)}
//         />
//       )}
//     </div>
//   );
// }
// import React, { useEffect, useState, useMemo } from "react";
// import { Search, Download } from "lucide-react";
// import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
// import AssignedOrdersPopup from "./AssignedOrdersPopup";

// export default function OrdersAssignedTable() {
//   const [deliveryMen, setDeliveryMen] = useState([]);
//   const [selected, setSelected] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   // pagination
//   const [page, setPage] = useState(1);
//   const [pageSize] = useState(5);

//   // filters
//   const [searchTerm, setSearchTerm] = useState("");
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await fetch("http://38.60.244.137:3000/connected-orders");
//         const data = await res.json();

//         if (data.success) {
//           setDeliveryMen(data.data || []);
//           setError("");
//         } else {
//           setError("Failed to fetch data");
//         }
//       } catch (err) {
//         setError("Something went wrong");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//     const interval = setInterval(fetchData, 5000); // ⚠️ reduced from 500ms

//     return () => clearInterval(interval);
//   }, []);

//   // =========================
//   // FILTER (same style as OrdersTable)
//   // =========================
//   const filtered = useMemo(() => {
//     return deliveryMen.filter((dm) => {
//       const statusText = dm.status || "";

//       // ALL SEARCH (like OrdersTable)
//       const matchesSearch =
//         dm.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         dm.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         dm.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         dm.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         statusText.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         String(dm.total_order).includes(searchTerm) ||
//         String(dm.assign_order).includes(searchTerm);

//       // DATE FILTER (same logic style)
//       let matchesDate = true;

//       if (fromDate || toDate) {
//         matchesDate = dm.orders?.some((order) => {
//           const d = new Date(order.created_at);
//           const orderDate = new Date(d);
//           orderDate.setHours(0, 0, 0, 0);

//           const from = fromDate ? new Date(fromDate) : null;
//           const to = toDate ? new Date(toDate) : null;

//           if (from) from.setHours(0, 0, 0, 0);
//           if (to) to.setHours(0, 0, 0, 0);

//           if (from && to) {
//             return orderDate >= from && orderDate <= to;
//           }

//           if (from || to) {
//             const target = from || to;
//             return orderDate.getTime() === target.getTime();
//           }

//           return true;
//         });
//       }

//       return matchesSearch && matchesDate;
//     });
//   }, [deliveryMen, searchTerm, fromDate, toDate]);

//   // =========================
//   // PAGINATION (same flow)
//   // =========================
//   const totalPages = Math.ceil(filtered.length / pageSize);

//   const paginated = filtered.slice(
//     (page - 1) * pageSize,
//     page * pageSize
//   );

//   useEffect(() => {
//     if (page > totalPages) setPage(1);
//   }, [filtered]);

//   // =========================
//   // EXPORT (XLSX like OrdersTable)
//   // =========================
//   const handleExport = () => {
//     try {
//       const exportData = filtered.map((dm, i) => ({
//         No: i + 1,
//         DeliveryID: dm.id,
//         Name: dm.name,
//         Email: dm.email,
//         Phone: dm.phone,
//         WorkType: dm.work_type,
//         Status: dm.status,
//         Rating: dm.rating,
//         TotalOrders: dm.total_order,
//         AssignedOrders: dm.assign_order,
//         CurrentOrders: dm.current_orders?.length || 0,
//       }));

//       const worksheet = XLSX.utils.json_to_sheet(exportData);

//       worksheet["!cols"] = [
//         { wch: 5 },
//         { wch: 15 },
//         { wch: 20 },
//         { wch: 20 },
//         { wch: 15 },
//         { wch: 15 },
//         { wch: 15 },
//         { wch: 15 },
//         { wch: 15 },
//         { wch: 15 },
//       ];

//       const workbook = XLSX.utils.book_new();
//       XLSX.utils.book_append_sheet(workbook, worksheet, "DeliveryMen");

//       const excelBuffer = XLSX.write(workbook, {
//         bookType: "xlsx",
//         type: "array",
//       });

//       const blob = new Blob([excelBuffer], {
//         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//       });

//       saveAs(blob, "assigned-orders.xlsx");
//     } catch (err) {
//       console.error(err);
//     }
//   };

//   // =========================
//   // UI
//   // =========================
//   return (
//     <div className="text-white mt-8 mb-8">

//       {/* HEADER */}
//       <div className="mb-4 flex flex-col md:flex-row justify-between gap-4">

//         <h2 className="text-2xl font-semibold text-[#B476FF]">
//           Orders Assigned Table
//         </h2>

//         <div className="flex gap-3 flex-wrap">

//           {/* SEARCH */}
//           <div className="relative">
//             <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-400" />
//             <input
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//               placeholder="Search all..."
//               className="rounded-2xl bg-neutral-900 border border-neutral-700 pl-8 pr-3 py-2 text-sm"
//             />
//           </div>

//           {/* EXPORT */}
//           <button
//             onClick={handleExport}
//             className="flex items-center gap-1 px-3 py-2 rounded-2xl border text-sm"
//           >
//             <Download size={14} /> Export
//           </button>

//           {/* DATE FILTER */}
//           <input
//             type="date"
//             value={fromDate}
//             onChange={(e) => setFromDate(e.target.value)}
//             className="rounded-2xl bg-purple-500 text-white px-3 py-2 text-sm"
//           />

//           <input
//             type="date"
//             value={toDate}
//             onChange={(e) => setToDate(e.target.value)}
//             className="rounded-2xl bg-purple-500 text-white px-3 py-2 text-sm"
//           />

//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-[#1a2030]/80 border border-slate-700 rounded-3xl p-6">

//         {loading ? (
//           <div className="text-center py-10">Loading...</div>
//         ) : error ? (
//           <div className="text-red-500 text-center py-10">{error}</div>
//         ) : paginated.length === 0 ? (
//           <div className="text-center py-10">No data found</div>
//         ) : (
//           <table className="w-full text-sm">

//             <thead className="text-slate-400 border-b border-slate-700">
//               <tr>
//                 <th>ID</th>
//                 <th>Name</th>
//                 <th>Email</th>
//                 <th>Phone</th>
//                 <th>Status</th>
//                 <th>Total</th>
//                 <th>Assigned</th>
//                 <th>Current</th>
//                 <th>Action</th>
//               </tr>
//             </thead>

//             <tbody>
//               {paginated.map((dm) => (
//                 <tr key={dm.id} className="border-b border-slate-800">
//                   <td className="text-cyan-400">{dm.id}</td>
//                   <td>{dm.name}</td>
//                   <td>{dm.email}</td>
//                   <td>{dm.phone}</td>
//                   <td className="text-yellow-400">{dm.status}</td>
//                   <td className="text-blue-400">{dm.total_order}</td>
//                   <td className="text-purple-400">{dm.assign_order}</td>
//                   <td className="text-pink-400">
//                     {dm.current_orders?.length || 0}
//                   </td>
//                   <td>
//                     <button
//                       onClick={() => setSelected(dm)}
//                       className="px-3 py-1 bg-purple-500 rounded-xl"
//                     >
//                       Details
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>

//           </table>
//         )}

//         {/* PAGINATION */}
//         <div className="flex justify-between mt-4 text-sm text-neutral-400">
//           <p>
//             Page {page} of {totalPages || 0}
//           </p>

//           <div className="flex gap-2">
//             <button
//               disabled={page === 1}
//               onClick={() => setPage(page - 1)}
//             >
//               Prev
//             </button>

//             <button
//               disabled={page === totalPages}
//               onClick={() => setPage(page + 1)}
//             >
//               Next
//             </button>
//           </div>
//         </div>

//       </div>

//       {selected && (
//         <AssignedOrdersPopup
//           delivery={selected}
//           close={() => setSelected(null)}
//         />
//       )}
//     </div>
//   );
// }
// import React, { useEffect, useState, useMemo } from "react";
// import { Search, Download, Eye } from "lucide-react";
// import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
// import AssignedOrdersPopup from "./AssignedOrdersPopup";

// export default function OrdersAssignedTable() {
//   const [data, setData] = useState([]);
//   const [selected, setSelected] = useState(null);

//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   const [page, setPage] = useState(1);
//   const [pageSize] = useState(5);

//   const [searchTerm, setSearchTerm] = useState("");
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");

//   // =========================
//   // FETCH
//   // =========================
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const res = await fetch(
//           "http://38.60.244.137:3000/connected-orders"
//         );
//         const json = await res.json();

//         if (json.success) {
//           setData(json.data || []);
//         } else {
//           setError("Failed to load data");
//         }
//       } catch (err) {
//         setError("Server error");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//     const interval = setInterval(fetchData, 5000);

//     return () => clearInterval(interval);
//   }, []);

//   // =========================
//   // FILTER (BEST LOGIC)
//   // =========================
//   const filtered = useMemo(() => {
//     return data.filter((dm) => {
//       const search = searchTerm.toLowerCase();

//       const matchesSearch =
//         dm.id?.toLowerCase().includes(search) ||
//         dm.name?.toLowerCase().includes(search) ||
//         dm.phone?.includes(search) ||
//         dm.email?.toLowerCase().includes(search) ||
//         dm.status?.toLowerCase().includes(search) ||
//         String(dm.assign_order).includes(search) ||
//         String(dm.current_orders?.length || 0).includes(search) ||
//         dm.orders?.some((o) =>
//           o.id?.toLowerCase().includes(search) ||
//           o.name?.toLowerCase().includes(search) ||
//           o.type?.toLowerCase().includes(search)
//         );

//       let matchesDate = true;

//       if (fromDate || toDate) {
//         matchesDate = dm.orders?.some((o) => {
//           const d = new Date(o.created_at);
//           d.setHours(0, 0, 0, 0);

//           const from = fromDate ? new Date(fromDate) : null;
//           const to = toDate ? new Date(toDate) : null;

//           if (from) from.setHours(0, 0, 0, 0);
//           if (to) to.setHours(0, 0, 0, 0);

//           if (from && to) return d >= from && d <= to;
//           if (from || to) return d.getTime() === (from || to).getTime();

//           return true;
//         });
//       }

//       return matchesSearch && matchesDate;
//     });
//   }, [data, searchTerm, fromDate, toDate]);

//   // =========================
//   // PAGINATION
//   // =========================
//   const totalPages = Math.ceil(filtered.length / pageSize);

//   const paginated = filtered.slice(
//     (page - 1) * pageSize,
//     page * pageSize
//   );

//   useEffect(() => {
//     if (page > totalPages) setPage(1);
//   }, [filtered]);

//   // =========================
//   // EXPORT (CLEAN + PRO LEVEL)
//   // =========================
//   const handleExport = () => {
//     const rows = [];

//     filtered.forEach((dm) => {
//       rows.push({
//         DeliveryID: dm.id,
//         Name: dm.name,
//         Email: dm.email,
//         Phone: dm.phone,
//         Status: dm.status,
//         Rating: dm.rating,
//         AssignedOrders: dm.assign_order,
//         CurrentOrders: dm.current_orders?.length || 0,
//         FinishedOrders: dm.finished_order_count,
//       });
//     });

//     const ws = XLSX.utils.json_to_sheet(rows);
//     const wb = XLSX.utils.book_new();
//     XLSX.utils.book_append_sheet(wb, ws, "Delivery");

//     const buffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });

//     const blob = new Blob([buffer], {
//       type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
//     });

//     saveAs(blob, "delivery-report.xlsx");
//   };

//   // =========================
//   // UI (MATCHED OrdersTable STYLE)
//   // =========================
//   return (
//     <div className="text-white">

//       {/* HEADER */}
//       <div className="mb-4 flex flex-col md:flex-row justify-between gap-4">

//         <h2 className="text-2xl font-semibold text-purple-400">
//           Delivery Dashboard
//         </h2>

//         <div className="flex flex-wrap gap-2">

//           {/* SEARCH */}
//           <div className="relative">
//             <Search
//               size={14}
//               className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500"
//             />
//             <input
//               value={searchTerm}
//               onChange={(e) => setSearchTerm(e.target.value)}
//               placeholder="Search delivery or order..."
//               className="pl-10 pr-4 py-2 rounded-2xl text-sm bg-slate-900/60 border border-slate-700 w-[250px]"
//             />
//           </div>

//           {/* EXPORT */}
//           <button
//             onClick={handleExport}
//             className="px-4 py-2 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400"
//           >
//             <Download size={14} /> Export
//           </button>

//           {/* DATE */}
//           <input
//             type="date"
//             value={fromDate}
//             onChange={(e) => setFromDate(e.target.value)}
//             className="rounded-2xl bg-purple-400 text-black px-3 py-1.5"
//           />

//           <input
//             type="date"
//             value={toDate}
//             onChange={(e) => setToDate(e.target.value)}
//             className="rounded-2xl bg-purple-400 text-black px-3 py-1.5"
//           />

//         </div>
//       </div>

//       {/* TABLE */}
//       <div className="bg-[#1a2030]/80 border border-slate-700 rounded-3xl p-6">

//         {loading ? (
//           <div className="text-center py-10">Loading...</div>
//         ) : error ? (
//           <div className="text-center text-red-500 py-10">{error}</div>
//         ) : paginated.length === 0 ? (
//           <div className="text-center py-10">No data</div>
//         ) : (
//           <table className="w-full text-sm">

//             <thead className="text-slate-400 border-b border-slate-700">
//               <tr>
//                 <th>ID</th>
//                 <th>Name</th>
//                 <th>Phone</th>
//                 <th>Status</th>
//                 <th>Assigned</th>
//                 <th>Current</th>
//                 <th>Finished</th>
//                 <th>Action</th>
//               </tr>
//             </thead>

//             <tbody>
//               {paginated.map((dm) => (
//                 <tr key={dm.id} className="border-b border-slate-800">

//                   <td className="text-cyan-400">{dm.id}</td>
//                   <td>{dm.name}</td>
//                   <td>{dm.phone}</td>
//                   <td className="text-yellow-400">{dm.status}</td>
//                   <td className="text-purple-400">{dm.assign_order}</td>
//                   <td className="text-pink-400">
//                     {dm.current_orders?.length || 0}
//                   </td>
//                   <td className="text-green-400">
//                     {dm.finished_order_count}
//                   </td>

//                   <td>
//                     <button
//                       onClick={() => setSelected(dm)}
//                       className="px-3 py-1 bg-purple-600 rounded-xl flex items-center gap-1"
//                     >
//                       <Eye size={14} /> View
//                     </button>
//                   </td>

//                 </tr>
//               ))}
//             </tbody>

//           </table>
//         )}

//         {/* PAGINATION */}
//         <div className="flex justify-between mt-4 text-sm text-neutral-400">
//           <p>Page {page} of {totalPages || 0}</p>

//           <div className="flex gap-2">
//             <button onClick={() => setPage(page - 1)} disabled={page === 1}>
//               Prev
//             </button>
//             <button onClick={() => setPage(page + 1)} disabled={page === totalPages}>
//               Next
//             </button>
//           </div>
//         </div>

//       </div>

//       {selected && (
//         <AssignedOrdersPopup
//           delivery={selected}
//           close={() => setSelected(null)}
//         />
//       )}

//     </div>
//   );
// }
import React, { useEffect, useState, useMemo } from "react";
import { Search, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import AssignedOrdersPopup from "./AssignedOrdersPopup";

export default function OrdersAssignedTable() {
  const [deliveryMen, setDeliveryMen] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [page, setPage] = useState(1);
  const [pageSize] = useState(5);

  const [searchTerm, setSearchTerm] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("http://38.60.244.137:3000/connected-orders");
        const data = await res.json();

        if (data.success) {
          setDeliveryMen(data.data || []);
          setError("");
        } else {
          setError("Failed to fetch data");
        }
      } catch (err) {
        setError("Something went wrong");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);

    return () => clearInterval(interval);
  }, []);

  // =========================
  // FILTER (same style as OrdersTable)
  // =========================
  const filtered = useMemo(() => {
    return deliveryMen.filter((dm) => {
      const matchesSearch =
        dm.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dm.id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dm.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dm.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dm.status?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        String(dm.total_order).includes(searchTerm) ||
        String(dm.assign_order).includes(searchTerm);

      let matchesDate = true;

      if (fromDate || toDate) {
        matchesDate = dm.orders?.some((order) => {
          const d = new Date(order.created_at);
          const orderDate = new Date(d);
          orderDate.setHours(0, 0, 0, 0);

          const from = fromDate ? new Date(fromDate) : null;
          const to = toDate ? new Date(toDate) : null;

          if (from) from.setHours(0, 0, 0, 0);
          if (to) to.setHours(0, 0, 0, 0);

          if (from && to) return orderDate >= from && orderDate <= to;
          if (from || to) {
            const target = from || to;
            return orderDate.getTime() === target.getTime();
          }
          return true;
        });
      }

      return matchesSearch && matchesDate;
    });
  }, [deliveryMen, searchTerm, fromDate, toDate]);

  // =========================
  // PAGINATION (same style)
  // =========================
  const totalPages = Math.ceil(filtered.length / pageSize);

  const paginated = filtered.slice(
    (page - 1) * pageSize,
    page * pageSize
  );

  useEffect(() => {
    if (page > totalPages) setPage(1);
  }, [filtered]);

  // =========================
  // EXPORT (same XLSX style)
  // =========================
  const handleExport = () => {
    const exportData = filtered.map((dm, i) => ({
      No: i + 1,
      ID: dm.id,
      Name: dm.name,
      Email: dm.email,
      Phone: dm.phone,
      WorkType: dm.work_type,
      Status: dm.status,
      Rating: dm.rating,
      TotalOrders: dm.total_order,
      AssignedOrders: dm.assign_order,
      CurrentOrders: dm.current_orders?.length || 0,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);

    worksheet["!cols"] = [
      { wch: 6 },
      { wch: 15 },
      { wch: 20 },
      { wch: 20 },
      { wch: 15 },
      { wch: 15 },
      { wch: 15 },
      { wch: 15 },
      { wch: 15 },
      { wch: 15 },
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Assigned");

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    saveAs(blob, "assigned-orders.xlsx");
  };

  // =========================
  // UI (MATCHED WITH OrdersTable)
  // =========================
  return (
    <div className="text-white">

      {/* HEADER (same layout) */}
      <div className="mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mt-6">

        <h2 className="text-2xl font-semibold text-purple-400">
          Orders Assigned Table
        </h2>

        <div className="flex flex-col md:flex-row gap-2 items-start md:items-center">

          {/* SEARCH (same style) */}
          <div className="relative">
            <Search
              size={14}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500"
            />
            <input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search..."
              className="pl-10 pr-4 py-2 rounded-2xl text-sm bg-slate-900/60 border border-slate-700 text-white outline-none focus:border-purple-500 w-[250px]"
            />
          </div>

          {/* EXPORT (same style) */}
          <button
            onClick={handleExport}
            className="px-4 py-2 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 text-sm font-medium hover:bg-purple-500/20 transition flex items-center gap-1"
          >
            <Download size={14} /> Export
          </button>

          {/* DATE INPUT (same style) */}
          <input
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            className="rounded-2xl bg-purple-400 text-neutral-900 px-3 py-1.5 text-sm"
          />

          <input
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            className="rounded-2xl bg-purple-400 text-neutral-900 px-3 py-1.5 text-sm"
          />

        </div>
      </div>

      {/* TABLE CONTAINER (same style) */}
      <div className="bg-[#1a2030]/80 backdrop-blur-xl border border-slate-700 rounded-3xl shadow-2xl p-6">

        {loading ? (
          <div className="text-center py-20 text-slate-400">
            Loading...
          </div>
        ) : error ? (
          <div className="text-center py-20 text-red-500">
            {error}
          </div>
        ) : paginated.length === 0 ? (
          <div className="text-center py-20 text-slate-400">
            No data found
          </div>
        ) : (
          <div className="overflow-x-auto">

            <table className="w-full text-sm">

              <thead className="text-slate-400 border-b border-slate-700">
                <tr>
                  <th className="py-4 text-left">ID</th>
                  <th className="py-4 text-left">Name</th>
                  <th className="py-4 text-left">Email</th>
                  <th className="py-4 text-left">Phone</th>
                  <th className="py-4 text-left">Status</th>
                  <th className="py-4 text-left">Total</th>
                  <th className="py-4 text-left">Assigned</th>
                  <th className="py-4 text-left">Current</th>
                  <th className="py-4 text-left">Action</th>
                </tr>
              </thead>

              <tbody>
                {paginated.map((dm) => (
                  <tr
                    key={dm.id}
                    className="border-b border-slate-800 hover:bg-slate-800/40"
                  >
                    <td className="py-4 text-cyan-400">{dm.id}</td>
                    <td className="py-4">{dm.name}</td>
                    <td className="py-4">{dm.email}</td>
                    <td className="py-4">{dm.phone}</td>
                    <td className="py-4 text-yellow-400">{dm.status}</td>
                    <td className="py-4 text-blue-400">{dm.total_order}</td>
                    <td className="py-4 text-purple-400">{dm.assign_order}</td>
                    <td className="py-4 text-pink-400">
                      {dm.current_orders?.length || 0}
                    </td>
                    <td className="py-4">
                      <button
                        onClick={() => setSelected(dm)}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-500 rounded-xl text-sm"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>

            </table>

          </div>
        )}

        {/* PAGINATION (same style) */}
        <div className="flex justify-between px-4 pt-4 text-sm text-neutral-400">
          <p>
            Page {page} of {totalPages || 0}
          </p>

          <div className="flex gap-2">
            <button
              disabled={page === 1}
              onClick={() => setPage(page - 1)}
              className="px-3 py-1 rounded-md border border-neutral-700"
            >
              Prev
            </button>

            <button
              disabled={page === totalPages}
              onClick={() => setPage(page + 1)}
              className="px-3 py-1 rounded-md border border-neutral-700"
            >
              Next
            </button>
          </div>
        </div>

      </div>

      {selected && (
        <AssignedOrdersPopup
          delivery={selected}
          close={() => setSelected(null)}
        />
      )}

    </div>
  );
}