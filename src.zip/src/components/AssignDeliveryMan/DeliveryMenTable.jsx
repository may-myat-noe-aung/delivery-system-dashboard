// import React, { useEffect, useState, useMemo } from "react";
// import { Search } from "lucide-react";

// export default function DeliveryMenTable() {
//   const [deliverymen, setDeliverymen] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [searchTerm, setSearchTerm] = useState("");
//   const [page, setPage] = useState(1);
//   const [pageSize] = useState(5);

//   const statusColors = {
//     active: "text-green-400",
//     inactive: "text-gray-400",
//     warning: "text-yellow-400",
//     banned: "text-red-400",
//   };

//   useEffect(() => {
//     const fetchDeliverymen = async () => {
//       try {
//         const res = await fetch("http://38.60.244.137:3000/deliverymen");
//         const data = await res.json();
//         setDeliverymen(data);
//       } catch (err) {
//         console.error(err);
//         setError("Failed to fetch delivery men.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchDeliverymen();
//     const interval = setInterval(fetchDeliverymen, 2000);
//     return () => clearInterval(interval);
//   }, []);

//   const filteredData = useMemo(() => {
//     return deliverymen.filter(
//       (item) =>
//         item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         item.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         item.phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
//         item.id?.toLowerCase().includes(searchTerm.toLowerCase()),
//     );
//   }, [deliverymen, searchTerm]);

//   const totalPages = Math.ceil(filteredData.length / pageSize);
//   const paginatedData = filteredData.slice(
//     (page - 1) * pageSize,
//     page * pageSize,
//   );

//   useEffect(() => {
//     if (page > totalPages) setPage(1);
//   }, [filteredData]);

//   return (
//     <div className="text-gray-100 font-sans mb-40">
//       {/* Header */}
//       <div className="mb-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 ">
//         <h2 className="text-2xl font-bold text-purple-400">
//           Delivery Men Table
//         </h2>

//         <div className="relative">
//           <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
//           <input
//             value={searchTerm}
//             onChange={(e) => setSearchTerm(e.target.value)}
//             placeholder="Search..."
//             className="rounded-xl bg-gray-800 border border-gray-700 pl-8 pr-3 py-2 text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-400"
//           />
//         </div>
//       </div>

//       {/* Table */}
//       <div className="bg-purple-500/50 backdrop-blur-xl border border-slate-700 rounded-3xl shadow-2xl p-6">
//         {loading ? (
//           <div className="text-center text-gray-500 py-10">
//             Loading delivery men...
//           </div>
//         ) : error ? (
//           <div className="text-center text-red-500 py-10">{error}</div>
//         ) : paginatedData.length === 0 ? (
//           <div className="text-center text-gray-500 py-10">
//             No delivery men found.
//           </div>
//         ) : (
//           <div className="overflow-x-auto">
//             <table className="w-full text-sm border-collapse">
//               <thead className="text-white border-b-2 border-purple-400">
//                 <tr>
//                   <th className="py-3 text-left">ID</th>
//                   <th className="py-3 text-left">Name</th>
//                   <th className="py-3 text-left">Email</th>
//                   <th className="py-3 text-left">Phone</th>
//                   <th className="py-3 text-left">Work Type</th>
//                   <th className="py-3 text-left">Rating</th>
//                   <th className="py-3 text-left">Total Orders</th>
//                   <th className="py-3 text-left">Assigned</th>
//                   <th className="py-3 text-left">Status</th>
//                 </tr>
//               </thead>

//               <tbody>
//                 {paginatedData.map((item) => (
//                   <tr
//                     key={item.id}
//                     className="border-b border-purple-400 hover:bg-purple-500/20 transition"
//                   >
//                     <td className="py-3 font-semibold text-cyan-400">
//                       {item.id}
//                     </td>
//                     <td className="py-3 font-semibold text-white-100">
//                       {item.name}
//                     </td>
//                     <td className="py-3 text-white">{item.email}</td>
//                     <td className="py-3 text-white">{item.phone}</td>
//                     {/* <td className="py-3 text-white">{item.work_type }</td>
//                      */}
//                     <td className="py-3 text-white">
//                       {item.work_type?.trim() ? item.work_type : "System"}
//                     </td>
//                     <td className="py-3 text-yellow-400 font-semibold">
//                       ⭐ {item.rating}
//                     </td>
//                     <td className="py-3 text-white">{item.total_order}</td>
//                     <td className="py-3 text-white">{item.assign_order}</td>
//                     <td
//                       className={`py-3 font-semibold ${statusColors[item.status?.toLowerCase()] || "text-white"}`}
//                     >
//                       {item.status}
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>

//             {/* Pagination */}
//             <div className="flex justify-between px-4 pt-4 text-sm text-white">
//               <p>
//                 Page {totalPages === 0 ? 0 : page} of {totalPages}
//               </p>
//               <div className="flex gap-2">
//                 <button
//                   disabled={page === 1}
//                   onClick={() => setPage(page - 1)}
//                   className="px-3 py-1 rounded-md border border-white disabled:opacity-50"
//                 >
//                   Prev
//                 </button>
//                 <button
//                   disabled={page === totalPages}
//                   onClick={() => setPage(page + 1)}
//                   className="px-3 py-1 rounded-md border border-white disabled:opacity-50"
//                 >
//                   Next
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }


import React, { useState, useEffect } from "react";
import { Download, Edit, Search, Star } from "lucide-react";

// import EditDeliveryMan from "./components/EditDeliveryMan";
// import DeleteDeliveryMan from "./components/DeleteDeliveryMan";
// import StatusDeliveryMan from "./components/StatusDeliveryMan";
import axios from "axios";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

export default function DeliveryTable({ setShowForm }) {
  const [deliverymen, setDeliverymen] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeUser, setActiveUser] = useState(null);
  const [actionLoading, setActionLoading] = useState({});
  // const [shopName, setShopName] = useState("");
  const [editModal, setEditModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // useEffect(() => {
  //   if (!shopId) return;

  //   const fetchDeliverymen = () => {
  //     axios
  //       .get(`http://38.60.244.137:3000/deliverymen-shop/${shopId}`)
  //       .then((res) => setDeliverymen(res.data?.data || res.data || []))
  //       .catch((err) => console.error("API Error:", err));
  //   };

  //   fetchDeliverymen(); // ချက်ချင်း load

  //   const interval = setInterval(fetchDeliverymen, 5000);

  //   return () => clearInterval(interval);
  // }, [shopId]);

  // useEffect(() => {
  //   if (!shopId) return;

  //   fetch(`http://38.60.244.137:3000/shops/${shopId}`)
  //     .then((res) => res.json())
  //     .then((data) => {
  //       if (data?.length > 0) {
  //         setShopName(data[0].shop_name);
  //       }
  //     })
  //     .catch((err) => console.error("Shop Error:", err));
  // }, [shopId]);

  useEffect(() => {
  const fetchDeliverymen = () => {
    axios
      .get("http://38.60.244.137:3000/deliverymen")
      .then((res) => setDeliverymen(res.data?.data || res.data || []))
      .catch((err) => console.error("API Error:", err));
  };

  fetchDeliverymen();

  const interval = setInterval(fetchDeliverymen, 1000);

  return () => clearInterval(interval);
}, []);  // useEffect(() => {

  //   if (!shopId) return;

  //   fetch(`http://38.60.244.137:3000/shops/${shopId}`)
  //     .then((res) => res.json())
  //     .then((data) => {
  //       if (data?.length > 0) {
  //         setShopName(data[0].shop_name);
  //       }
  //     })
  //     .catch((err) => console.error("Shop Error:", err));
  // }, [shopId]);

  const splitDateTime = (datetime) => {
    if (!datetime) return ["-", "-"];

    const parts = datetime.split(" ");
    const date = parts[0] || "-";
    const time = parts[1] ? parts[1].slice(0, 8) : "-";

    return [date, time];
  };

  const filteredUsers = deliverymen.filter((delivery) => {
    const term = searchTerm.toLowerCase();

    return (
      delivery.name?.toLowerCase().includes(term) ||
      delivery.id?.toLowerCase().includes(term) ||
      delivery.email?.toLowerCase().includes(term) ||
      delivery.phone?.toLowerCase().includes(term) ||
      delivery.status?.toLowerCase().includes(term) ||
      delivery.rating?.toString().toLowerCase().includes(term) ||
      delivery.finished_order_count?.toString().toLowerCase().includes(term) ||
      delivery.assign_order?.toString().toLowerCase().includes(term)
    );
  });

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);

  const startIndex = (currentPage - 1) * itemsPerPage;

  const paginatedUsers = filteredUsers.slice(
    startIndex,
    startIndex + itemsPerPage,
  );

  useEffect(() => setCurrentPage(1), [searchTerm]);

  const openEdit = (delivery) => {
    setActiveUser(delivery);
    setEditModal(true);
  };



  const handleExport = () => {
  try {
    const exportData = [
      {
        ID: "ID",
        Name: "Name",
        Email: "Email",
        Phone: "Phone",
        WorkType: "Work Type",
        Finished: "Finished",
        Assigned: "Assigned",
        Status: "Status",
        Rating: "Rating",
        Date: "Date",
        Time: "Time",
      },
      ...filteredUsers.map((delivery) => {
        const [date, time] = splitDateTime(delivery.created_at);

        return {
          ID: delivery.id,
          Name: delivery.name,
          Email: delivery.email,
          Phone: delivery.phone,
          WorkType: delivery.work_type,
          Finished: delivery.finished_order_count,
          Assigned: delivery.assign_order,
          Status: delivery.status,
          Rating: delivery.rating,
          Date: date,
          Time: time,
        };
      }),
    ];

    const worksheet = XLSX.utils.json_to_sheet(exportData);

    // optional column width
    worksheet["!cols"] = [
      { wch: 10 },
      { wch: 20 },
      { wch: 25 },
      { wch: 15 },
      { wch: 15 },
      { wch: 10 },
      { wch: 10 },
      { wch: 15 },
      { wch: 10 },
      { wch: 15 },
      { wch: 10 },
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Delivery Men");

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `deliverymen_shop_${shopId}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  } catch (error) {
    console.error("Export error:", error);
  }
};

  return (
    <div className="bg-[#0f172a] text-gray-100 min-h-full pt-6">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
    
         <h2 className="text-2xl font-semibold text-[#B476FF]">
           Delivery Man Table
        </h2>

        <div className="flex items-center gap-3">

          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Search
                size={14}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500"
              />

              <input
                type="text"
                placeholder="Search Deliverymen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 rounded-2xl text-sm bg-slate-900/60 border border-slate-700 text-white outline-none focus:border-purple-500 w-full sm:w-[250px]"
              />
            </div>
          </div>

          <button
            onClick={handleExport}
            className="px-4 py-2 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 text-sm font-medium hover:bg-purple-500/20 transition flex items-center gap-1"
          >
            <Download size={14} /> Export
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto bg-[#1a2030]/80 backdrop-blur-xl border border-slate-700 rounded-3xl shadow-2xl p-6">
        <table className="w-full text-sm">
          <thead className="text-slate-400 border-b border-slate-700">
            <tr>
              {[
                // "ID",
                "Deliveryman",
                "Email",
                "Phone",
                "Work Type",
                "Orders",
                "Status",
                "Rating",
                "Date ",
                // "Action",
              ].map((col) => (
                <th key={col} className="p-4 text-center font-medium ">
                  {col}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {paginatedUsers.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center p-8 text-gray-400">
                  No results found.
                </td>
              </tr>
            ) : (
              paginatedUsers.map((delivery) => (
                <tr
                  key={delivery.id}
                  className={`border-t transition-all duration-300 ${
                    delivery.status === "active"
                      ? "bg-green-900/30 hover:bg-green-900/40 border-green-700"
                      : delivery.status === "warning"
                        ? "bg-red-900/30 hover:bg-red-900/40 border-red-700"
                        : "hover:bg-slate-800 border-slate-700"
                  }`}
                >
                  {/* Profile */}
                  <td className="p-4">
                    <div className="flex items-center gap-2 2xl:gap-3">
                      {delivery.photo ? (
                        <img
                          src={`http://38.60.244.137:3000/deliverymen-uploads/${delivery.photo}`}
                          alt={delivery.name}
                          className="w-11 h-11 rounded-2xl object-cover ring-2 ring-purple-500/20"
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 font-semibold">
                          {delivery.name?.charAt(0).toUpperCase()}
                        </div>
                      )}

                      <div>
                        <h4 className="font-medium text-white">
                          {delivery.name}
                        </h4>

                        <p className="text-xs text-neutral-500 mt-1">
                          ID: {delivery.id}
                        </p>
                      </div>
                    </div>
                  </td>
                  {/* <td className="p-4 text-center">{delivery.email}</td> */}
                  <td className="p-4 text-center break-words whitespace-normal max-w-[150px]">
                    {delivery.email}
                  </td>

                  <td className="p-4 text-center">{delivery.phone}</td>

                  <td className="p-4 text-center">{delivery.work_type || "System"}</td>

                  <td className="p-4 text-center">
                    <div className="flex flex-col text-sm">
                      <span>Finished: {delivery.finished_order_count}</span>
                      <span>Assigned: {delivery.assign_order}</span>
                    </div>
                  </td>

                  {/* STATUS BADGE */}
                  {/* <td className="p-4 text-center">
                    <StatusDeliveryMan
                      delivery={delivery}
                      loading={actionLoading}
                      setLoading={setActionLoading}
                      onSuccess={(id, status) =>
                        setDeliverymen((prev) =>
                          prev.map((u) => (u.id === id ? { ...u, status } : u)),
                        )
                      }
                    />
                  </td> */}
                      {/* <td className="p-4 text-center">
                    <StatusDeliveryMan
                      delivery={delivery}
                      loading={actionLoading}
                      setLoading={setActionLoading}
                      onSuccess={(id, status) =>
                        setDeliverymen((prev) =>
                          prev.map((u) => (u.id === id ? { ...u, status } : u)),
                        )
                      }
                    />
                  </td> */}
     <td className="p-4 text-center">
  <button
    onClick={() =>
      toggleStatus(
        delivery,
        delivery.status === "active" ? "warning" : "active"
      )
    }
    disabled={!!actionLoading[delivery.id]}
    className={`px-3 py-1.5 rounded-full text-xs border transition ${
      delivery.status === "active"
        ? "bg-green-500/10 text-green-500 border-green-500 hover:bg-green-500/20"
        : "bg-red-500/10 text-red-500 border-red-500 hover:bg-red-500/20"
    }`}
  >
    {delivery.status === "active" ? "Active" : "Warning"}
  </button>
</td>
                  {/* <td className="p-4 text-center">{delivery.rating || "-"}</td> */}
                  <td className="p-4 text-center">
                    <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-sm">
                      <Star className="h-4 w-4 fill-yellow-400" />
                      {delivery.rating}
                    </div>
                  </td>
                  <td className="p-4 text-center">
                    {splitDateTime(delivery.created_at)[0]} <br />
                    {/* {splitDateTime(delivery.created_at)[1]} */}
                  </td>
                  {/* <td className="py-4 px-4">
                    <div className="flex justify-center  items-center gap-1 2xl:gap-2 flex-wrap">
                      <button
                        onClick={() => openEdit(delivery)}
                        className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/20 flex items-center justify-center hover:bg-amber-400/70 hover:text-white transition-all duration-200 shadow-sm"
                      >
                        <Edit size={16} />
                      </button>

                      <DeleteDeliveryMan
                        delivery={delivery}
                        loading={actionLoading}
                        setLoading={setActionLoading}
                        onSuccess={(id) =>
                          setDeliverymen((prev) =>
                            prev.filter((u) => u.id !== id),
                          )
                        }
                      />
                    </div>
                  </td> */}
                </tr>
              ))
            )}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="flex justify-between px-4 pt-4 text-sm text-neutral-400">
          <p>
            Page {totalPages === 0 ? 0 : currentPage} of {totalPages}
          </p>

          <div className="flex justify-center items-center gap-2 pt-4 text-sm text-neutral-400">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => p - 1)}
              className="px-3 py-1 rounded-md border border-neutral-700"
            >
              Prev
            </button>

            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setCurrentPage(p)}
                className={`px-3 py-1 rounded-md border border-neutral-700 ${
                  currentPage === p
                    ? "bg-purple-500 text-white border-purple-600"
                    : ""
                }`}
              >
                {p}
              </button>
            ))}

            <button
              disabled={currentPage === totalPages || totalPages === 0}
              onClick={() => setCurrentPage((p) => p + 1)}
              className="px-3 py-1 rounded-md border border-neutral-700"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* <EditDeliveryMan
        open={editModal}
        activeUser={activeUser}
        setEditModal={setEditModal}
        setDeliverymen={setDeliverymen}
      /> */}
    </div>
  );
}