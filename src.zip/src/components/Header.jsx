import React from "react";
import {
  Bell,
  User,
  Menu,
} from "lucide-react";
import { useLocation } from "react-router-dom";

const Header = ({ collapsed, setCollapsed }) => {
  const location = useLocation();

  const getPageTitle = () => {
    const path = location.pathname;

    if (path === "/") return "Dashboard";
    if (path.startsWith("/shop")) return "Shop";
    if (path.startsWith("/report")) return "Report";
    if (path.startsWith("/management")) return "Management";
    if (path.startsWith("/setting")) return "Settings";
    if (path.startsWith("/orders/assignment"))
      return "Assign Delivery";
    if (path.startsWith("/delivery/add-delivery-men"))
      return "Add Delivery Man";
    if (path.startsWith("/delivery/track-delivery-men"))
      return "Track Delivery Man";

    return "Dashboard";
  };

  return (
    <header className="h-16 bg-gray-900 border-b border-gray-800 flex items-center justify-between px-6">
      {/* Left */}
      <div className="flex items-center gap-4">
        {/* <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg hover:bg-gray-800 transition"
        >
          <Menu className="w-5 h-5 text-gray-300" />
        </button> */}

        <h1 className="text-xl font-semibold text-[#B476FF]">
          {getPageTitle()}
        </h1>
      </div>

      {/* Right */}
      <div className="flex items-center gap-4">
        <button
          className="
            relative
            p-2
            rounded-xl
            bg-gray-800
            hover:bg-gray-700
            transition
          "
        >
          <Bell className="w-5 h-5 text-gray-300" />

          <span
            className="
              absolute
              -top-1
              -right-1
              w-2.5
              h-2.5
              bg-red-500
              rounded-full
            "
          />
        </button>
<div className="w-px h-6 bg-[#B476FF]"></div>
        <div
          className="
            flex items-center gap-3
           
            py-2
            rounded-xl
          "
        >
          <div
            className="
              w-9 h-9
              rounded-full
              bg-gradient-to-r
              from-purple-500
              to-fuchsia-500
              flex items-center justify-center
            "
          >
            <User className="w-4 h-4 text-white" />
          </div>

          <div className="hidden md:block">
            <p className="text-sm font-medium text-white">
              Admin
            </p>
            <p className="text-xs text-gray-400">
              Owner
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;